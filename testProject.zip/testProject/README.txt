rules:
mnthsum should never be empty... atleast 1 entry should be there so that the last date of accounting can be viewed
when adding new employee make sure no field is left unanswered
when putting date of absence dont use extra comma(',') or periods('.')
when adding advance the unanswered value should be a hyphen('-') but months and emi both cant be filled or unfilled